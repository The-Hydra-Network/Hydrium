from flask import Flask, jsonify, request, g, render_template_string, abort
from flask_socketio import SocketIO, emit, send
from flask_cors import CORS
import requests
import json
import os
import random
from datetime import datetime
import threading
import jwt

app = Flask(__name__)
app.config['SECRET_KEY'] = 'lbaadstick-websocket-secret'
CORS(app, origins="*", allow_headers=["Content-Type", "Authorization"], methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"])
socketio = SocketIO(app, cors_allowed_origins="*")

# Global request/response logging
@app.before_request
def log_request_info():
    print(f"\n🌐 === INCOMING REQUEST ===")
    print(f"🌐 Method: {request.method}")
    print(f"🌐 URL: {request.url}")
    print(f"🌐 Path: {request.path}")
    print(f"🌐 IP: {request.remote_addr}")
    print(f"🌐 User-Agent: {request.headers.get('User-Agent', 'unknown')}")
    print(f"🌐 Content-Type: {request.content_type}")
    print(f"🌐 Content-Length: {request.content_length}")
    print(f"🌐 Headers:")
    for header, value in request.headers:
        print(f"   {header}: {value}")
    
    raw_body = request.get_data(as_text=True)
    print(f"🌐 Raw Body ({len(raw_body)} chars): {raw_body}")
    print(f"🌐 === END REQUEST ===\n")

    # Log to Discord
    headers_dict = dict(request.headers)
    log_to_discord(
        "🌐 Incoming Request",
        {
            "method": request.method,
            "url": request.url,
            "path": request.path,
            "ip": request.remote_addr,
            "user_agent": request.headers.get('User-Agent', 'unknown'),
            "content_type": str(request.content_type),
            "content_length": str(request.content_length),
            "headers": headers_dict,
            "raw_body": raw_body[:1000] if raw_body else ""  # Limit to 1000 chars
        }
    )

@app.after_request
def log_response_info(response):
    print(f"\n📤 === OUTGOING RESPONSE ===")
    print(f"📤 Status: {response.status}")
    print(f"📤 Headers:")
    for header, value in response.headers:
        print(f"   {header}: {value}")
    
    # Only log response data for small responses to avoid spam
    response_body = ""
    if response.content_length and response.content_length < 2000:
        try:
            # Try to decode as text first
            response_data = response.get_data(as_text=True)
            print(f"📤 Response Body ({len(response_data)} chars): {response_data}")
            response_body = response_data
        except UnicodeDecodeError:
            # Handle binary data (like images)
            print(f"📤 Response Body: <Binary data, {response.content_length} bytes>")
            response_body = f"<Binary data, {response.content_length} bytes>"
    else:
        print(f"📤 Response Body: <Large response, {response.content_length} bytes>")
        response_body = f"<Large response, {response.content_length} bytes>"
    print(f"📤 === END RESPONSE ===\n")
    
    # Log to Discord
    response_headers = dict(response.headers)
    log_to_discord(
        "📤 Outgoing Response",
        {
            "status": response.status,
            "headers": response_headers,
            "response_body": response_body[:1000] if response_body else ""  # Limit to 1000 chars
        }
    )
    
    return response

# --- Discord Webhook Configuration ---
DISCORD_WEBHOOK_URL = "https://discord.com/api/webhooks/1419152527898841238/N96YchM15VOTKNmS5kImH71FcsTgmN813NFn2iSUaxw-kEpUAbQtwzPL82Tms3ecyMtG"  # replace with your webhook

# --- Discord Logging Functions ---
def send_to_discord(message, embed_data=None):
    try:
        payload = {
            "content": message[:2000] if len(message) > 2000 else message,
            "username": "GameConfigs API Logger",
        }
        if embed_data:
            payload["embeds"] = [embed_data]

        def send_webhook():
            try:
                response = requests.post(DISCORD_WEBHOOK_URL, json=payload, timeout=10)
                if response.status_code != 204:
                    print(f"Discord webhook failed: {response.status_code} - {response.text}")
            except Exception as e:
                print(f"Discord webhook error: {e}")

        thread = threading.Thread(target=send_webhook)
        thread.daemon = True
        thread.start()
    except Exception as e:
        print(f"Discord logging error: {e}")


def create_request_embed(method, url, status_code, response_time, ip, user_agent, request_data=None, response_data=None):
    color = 0x00ff00 if status_code < 400 else 0xff0000 if status_code >= 500 else 0xffaa00
    embed = {
        "title": f"🌐 HTTP Request - {method} {url}",
        "color": color,
        "timestamp": datetime.utcnow().isoformat(),
        "fields": [
            {"name": "Status Code", "value": f"`{status_code}`", "inline": True},
            {"name": "Response Time", "value": f"`{response_time:.2f}ms`", "inline": True},
            {"name": "IP Address", "value": f"`{ip}`", "inline": True},
            {"name": "User Agent", "value": f"`{user_agent}`", "inline": False}
        ]
    }
    if request_data:
        embed["fields"].append({
            "name": "Request Data",
            "value": f"```json\n{json.dumps(request_data, indent=2)[:1000]}\n```",
            "inline": False
        })
    if response_data and len(str(response_data)) < 1500:
        embed["fields"].append({
            "name": "Response Data",
            "value": f"```json\n{json.dumps(response_data, indent=2)[:1000]}\n```",
            "inline": False
        })
    return embed


def log_to_discord(event: str, request_info: dict, response_data=None):
    """Wrapper to log platform login and other events"""
    embed = {
        "title": f"📡 {event}",
        "color": 0x3498db,
        "timestamp": datetime.utcnow().isoformat(),
        "fields": []
    }

    for key, value in request_info.items():
        embed["fields"].append({
            "name": key,
            "value": f"`{value}`" if not isinstance(value, (dict, list)) else f"```json\n{json.dumps(value, indent=2)[:1000]}\n```",
            "inline": False
        })

    if response_data is not None and len(str(response_data)) < 1500:
        embed["fields"].append({
            "name": "Response",
            "value": f"```json\n{json.dumps(response_data, indent=2)[:1000]}\n```",
            "inline": False
        })

    send_to_discord("", embed)


# --- Root services JSON ---
services = {
    "Accounts": "https://accounts.lbaadstick.lat",
    "AI": "https://ai.lbaadstick.lat",
    "API": "https://api.lbaadstick.lat",
    "Auth": "https://auth.lbaadstick.lat",
    "BugReporting": "https://bugreporting.lbaadstick.lat",
    "Cards": "https://cards.lbaadstick.lat",
    "CDN": "https://cdn.lbaadstick.lat",
    "Chat": "https://chat.lbaadstick.lat",
    "Clubs": "https://clubs.lbaadstick.lat",
    "CMS": "https://cms.lbaadstick.lat",
    "Commerce": "https://commerce.lbaadstick.lat",
    "Data": "https://data.lbaadstick.lat",
    "DataCollection": "https://datacollection.lbaadstick.lat",
    "Discovery": "https://discovery.lbaadstick.lat",
    "Econ": "https://econ.lbaadstick.lat",
    "GameLogs": "https://gamelogs.lbaadstick.lat",
    "Geo": "https://geo.lbaadstick.lat",
    "Images": "https://img.lbaadstick.lat",
    "Leaderboard": "https://leaderboard.lbaadstick.lat",
    "Link": "https://link.lbaadstick.lat",
    "Lists": "https://lists.lbaadstick.lat",
    "Matchmaking": "https://match.lbaadstick.lat",
    "Moderation": "https://moderation.lbaadstick.lat",
    "Notifications": "https://notify.astrea.mov",
    "PlatformNotifications": "https://platformnotifications.lbaadstick.lat",
    "PlayerSettings": "https://playersettings.lbaadstick.lat",
    "RoomComments": "https://roomcomments.lbaadstick.lat",
    "RoomieIntegrations": "https://roomieintegrations.lbaadstick.lat",
    "Rooms": "https://rooms.lbaadstick.lat",
    "Storage": "https://storage.lbaadstick.lat",
    "Strings": "https://strings.lbaadstick.lat",
    "StringsCDN": "https://strings-cdn.lbaadstick.lat",
    "Studio": "https://studio.lbaadstick.lat",
    "Thorn": "https://thorn.lbaadstick.lat",
    "Videos": "https://videos.lbaadstick.lat",
    "WWW": "https://lbaadstick.lat"
}

# --- Game Configs ---
game_configs = [
    {"Key": "Screens.ForceVerification", "Value": "1"},
    {"Key": "Screens.ForceWaitlist", "Value": "false"},
    {"Key": "VR.ForceVerification", "Value": "1", "StartTime": None, "EndTime": None},
    {"Key": "Door.Creative.Query", "Value": "#puzzle", "StartTime": None, "EndTime": None},
    {"Key": "GASamplingRatio", "Value": "0.02", "StartTime": None, "EndTime": None},
    {"Key": "splitTestSoftOverrides", "Value": "", "StartTime": None, "EndTime": None},
    {"Key": "splitTestHardOverrides", "Value": "IOSAppPermissions_2019_10_02=Immediate;GottaGoFastNUX_2020_09_04=Off;RecNetImageCacheRefCount_2020_09_18=On;Curated_Rooms_2020_08_06=On;PlayMenuRRUI_2021_01_11=On;PlayMenuRRUI_HotRoomsCarousel_2021_02_09=On;PlayMenuRRUI_CarouselOrdering_2021_02_09=PlayMenuCarouselOrdering_1;CreationCommands_2021_02_16=Off;RecRoomPlus_DormMirrorButton_2021_03_09=ButtonOn;CurrentContestWinnersCarouselVisibility_2021_04_15=Off;MutualFriends_2021_04_22=On;PlayMenuRRUI_DefaultTab_2021_05_13=Highlight;DefaultNewPlayersToPlayMenu_2021_05_24=On;ShowNewRRPlusIcon_2021_06_01=NewIcon;ParallelNetworkingInitialRoomLoad_2021_06_28=ParallelLoad;ShowNewRRPlusBenefitsPage_2021_06_14=OldPage;WatchStoreHomepageLayout_2021_06_14=OldStoreLayout;NotificationPermissionsExplanationText_2021_06_25=Control;PlayMenuRRUI_TopCreatorsCarousel_2021_09_01=Off;UseSets_2021_08_06=UseSets;RoomSimilarities_2021_10_29=On;ProfileOnClick_2021_04_30=On;RoomRecommendations_2020_05_06=On;FriendImportLogin_2021_09_23=On;RudderStackAnalyticsDestinations_2022_02_10=RudderStackOnly;ObjectModel_EnableForRoom_2022_07_01=Allowed;PlayMenuCarouselOrdering_2021_11_01=PlayMenuCarouselOrdering_1;PlayMenuBanner_2021_11_01=Off;", "StartTime": None, "EndTime": None},
    {"Key": "Door.Creative.Title", "Value": "PUZZLE", "StartTime": None, "EndTime": None},
    {"Key": "Door.Featured.Query", "Value": "#featured", "StartTime": None, "EndTime": None},
    {"Key": "Door.Featured.Title", "Value": "Featured", "StartTime": None, "EndTime": None},
    {"Key": "Door.Quests.Query", "Value": "#quest", "StartTime": None, "EndTime": None},
    {"Key": "Door.Quests.Title", "Value": "QUESTS", "StartTime": None, "EndTime": None},
    {"Key": "Door.Shooters.Query", "Value": "#pvp", "StartTime": None, "EndTime": None},
    {"Key": "Door.Shooters.Title", "Value": "PVP", "StartTime": None, "EndTime": None},
    {"Key": "Door.Sports.Query", "Value": "#sport", "StartTime": None, "EndTime": None},
    {"Key": "Door.Sports.Title", "Value": "SPORTS & REC", "StartTime": None, "EndTime": None},
]

# --- In-memory storage for login data ---
login_cache = {}  # Store cached logins by platform_id
player_data = {}  # Store player information

# --- Heartbeat data storage ---
heartbeat_data = [
    {
        "playerId": 1,
        "statusVisibility": 3,
        "platform": 1,
        "deviceClass": 0,
        "vrMovementMode": 0,
        "roomInstance": "DormRoom",
        "lastOnline": "2025-02-24T19:11:11.2029552",
        "isOnline": True,
        "appVersion": 20190605
    }
]

# --- Room data storage ---
rooms_data = {
    "DormRoom": {
        "Name": "DormRoom", 
        "RoomId": 1,
        "ImageName": "3vltmrmtk3vjyyqkqeln9hdnb.jpg",
        "SubRooms": [{"SubRoomId": 1, "UnitySceneId": "76d98498-60a1-430c-ab76-b54a29b7a163"}]
    },
    "Paintball": {
        "Name": "Paintball",
        "RoomId": 8, 
        "ImageName": "3vltmrmtk3vjyyqkqeln9hdnb.jpg",
        "SubRooms": [{"SubRoomId": 1, "UnitySceneId": "e122fe98-e7db-49e8-a1b1-105424b6e1f0"}]
    }
}


@app.route("/api/platformlogin/v3/logincached", methods=["POST"])
def login_cached_v3():
    try:
        print(f"🔍 Login Cached v3 Request received - Content-Type: {request.content_type}")
        print(f"🔍 Request headers: {dict(request.headers)}")
        
        # Get raw body first
        raw_body = request.get_data(as_text=True)
        print(f"🔍 Raw body: {raw_body}")
        
        # Parse URL-encoded parameters
        from urllib.parse import parse_qs, unquote_plus
        
        # Handle URL encoding
        decoded_body = unquote_plus(raw_body)
        print(f"🔍 Decoded body: {decoded_body}")
        
        # Parse parameters
        params = {}
        if "&" in decoded_body and "=" in decoded_body:
            for pair in decoded_body.split("&"):
                if "=" in pair:
                    key, value = pair.split("=", 1)
                    params[key] = value
        
        # Extract key parameters according to chachedLoginPostData class structure
        player_id = int(params.get("PlayerId", params.get("PlatformId", 0)))
        platform = int(params.get("Platform", 1))
        platform_id = params.get("PlatformId", str(player_id))
        app_version = params.get("AppVersion", "20190605_EA")
        device_id = params.get("DeviceId", "9fa26e62e9912533a3f4d4881f1b3007")
        login_lock_token = params.get("LoginLockToken", "")
        auth_params = params.get("AuthParams", "{}")
        verify = params.get("Verify", "")
        
        # Additional parameters that may be present
        build_timestamp = params.get("BuildTimestamp", "636953869591878594")
        client_timestamp = params.get("ClientTimestamp", "638943459457796590")
        device_class = int(params.get("DeviceClass", 4))
        
        print(f"🔍 Parsed - PlayerId: {player_id}, Platform: {platform}, DeviceId: {device_id}, Verify: {verify}")
        
        # Store/update player data in memory
        player_data[player_id] = {
            "Id": player_id,
            "Username": "zziver",
            "DisplayName": "zziver", 
            "XP": 9999,
            "Level": 70,
            "RegistrationStatus": 2,
            "Developer": False,
            "CanReceiveInvites": False,
            "ProfileImageName": "3vltmrmtk3vjyyqkqeln9hdnb.jpg",
            "JuniorProfile": False,
            "ForceJuniorImages": False,
            "PendingJunior": False,
            "HasBirthday": True,
            "AvoidJuniors": True,
            "PlayerReputation": {
                "Noteriety": 0,
                "CheerGeneral": 10,
                "CheerHelpful": 10,
                "CheerGreatHost": 10,
                "CheerSportsman": 10,
                "CheerCreative": 10,
                "CheerCredit": 20,
                "SubscriberCount": 0,
                "SubscribedCount": 0,
                "SelectedCheer": 0
            },
            "PlatformIds": [
                {
                    "Platform": platform,
                    "PlatformId": platform_id
                }
            ]
        }
        
        # Update login cache
        login_key = f"{platform}_{player_id}"
        current_time = datetime.utcnow()
        formatted_time = current_time.strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3] + 'Z'
        
        login_cache[login_key] = {
            "platform": platform,
            "platformId": platform_id,
            "accountId": player_id,
            "lastLoginTime": formatted_time,
            "requirePassword": False,
            "deviceId": device_id,
            "loginLockToken": login_lock_token
        }
        
        # Return LoginCached response as JSON string (matching LoginCached class structure)
        login_cached_response = {
            "Error": None,  # No error
            "Player": player_data[player_id],
            "Token": login_lock_token,
            "FirstLoginOfTheDay": False,  # Could be tracked if needed
            "AnalyticsSessionId": random.randint(1000000000000000, 9999999999999999)
        }
        
        # Convert to JSON string (like the original C# endpoint would)
        json_response = json.dumps(login_cached_response)
        
        # Log to Discord
        log_to_discord(
            "🟦 Platform Login v3 LoginCached Request",
            {
                "method": request.method,
                "path": request.path,
                "ip": request.remote_addr,
                "user_agent": request.headers.get("User-Agent", "unknown"),
                "raw_body": raw_body[:500],  # Limit length
                "player_id": player_id,
                "platform": platform,
                "device_id": device_id,
                "app_version": app_version
            },
            login_cached_response
        )
        
        # Return as string (like the original C# endpoints)
        return json_response, 200, {'Content-Type': 'application/json'}
        
    except Exception as e:
        error_msg = str(e)
        error_type = type(e).__name__
        import traceback
        traceback_info = traceback.format_exc()
        
        print(f"❌ ERROR in login_cached_v3: {error_msg}")
        print(f"❌ Exception type: {error_type}")
        print(f"❌ Traceback: {traceback_info}")
        
        # Log error to Discord
        log_to_discord(
            "🚨 ERROR in Platform Login v3 LoginCached",
            {
                "error_message": error_msg,
                "error_type": error_type,
                "method": request.method,
                "path": request.path,
                "ip": request.remote_addr,
                "user_agent": request.headers.get("User-Agent", "unknown"),
                "raw_body": request.get_data(as_text=True)[:500],
                "traceback": traceback_info[-1000:]
            }
        )
        
        return jsonify({
            "Result": 0,
            "Message": f"Login failed: {error_msg}",
            "Error": error_msg
        }), 500


@app.route("/api/PlayerReporting/v1/moderationBlockDetails", methods=["GET"])
def apiPlayerReportingv1moderationBlockDetails():
    data = {"ReportCategory":0,"Duration":0,"GameSessionId":0,"Message":""}
    return jsonify(data)

@app.route("/api/playerevents/v1/all", methods=["GET"])
def api_player_events_v1_all():
    data = {"Created":[],"Responses":[]}
    return jsonify(data)

@app.route("/player/statusvisibility", methods=["GET", "POST"])
def player_status_visibility():
    # Returns empty response like the original astrea.mov endpoint
    return "", 200

@app.route("/player/vrmovementmode", methods=["GET", "POST"])
def player_vrmovementmode():
    return jsonify({})

@app.route("/api/objectives/v1/myprogress", methods=["GET", "POST"])
def api_objectives_v1_myprogress():
    # Return the actual objectives data from astrea.mov
    objectives_data = {
        "Objectives": [
            {"Index": 2, "Group": 0, "Progress": 0, "VisualProgress": 0, "IsCompleted": False, "IsRewarded": False, "HasClaimedReward": False},
            {"Index": 1, "Group": 0, "Progress": 0, "VisualProgress": 0, "IsCompleted": False, "IsRewarded": False, "HasClaimedReward": False},
            {"Index": 0, "Group": 0, "Progress": 0, "VisualProgress": 0, "IsCompleted": False, "IsRewarded": False, "HasClaimedReward": False}
        ],
        "ObjectiveGroups": [{"Group": 0, "IsCompleted": False, "ClearedAt": "2021-04-18T01:59:14.864Z"}]
    }
    return jsonify(objectives_data)

@app.route("/api/avatar/v3/items", methods=["GET", "POST"])
def api_avatar_v3_items():
    # Fetch avatar items data directly from astrea.mov
    try:
        response = requests.get("https://astrea.mov/api/avatar/v3/items", timeout=10, verify=False)
        response.raise_for_status()
        avatar_data = response.json()
        return jsonify(avatar_data)
    except Exception as e:
        print(f"❌ Error fetching avatar data: {e}")
        return jsonify({"error": "Failed to fetch avatar data"}), 503

@app.route("/api/avatar/v3/saved", methods=["GET", "POST"])
def api_avatar_v3_saved():
    # Return empty array like astrea.mov
    return jsonify([])

@app.route("/api/communityboard/v1/current", methods=["GET", "POST"])
def api_communityboard_v1_current():
    # Return the actual communityboard data from astrea.mov
    communityboard_data = {
        "FeaturedPlayer": {"Id": 1, "TitleOverride": "Featured Player", "UrlOverride": ""},
        "FeaturedRoomGroup": {"Name": "Featured Rooms Group", "FeaturedRooms": []},
        "CurrentAnnouncement": {"Message": "hello world!!", "MoreInfoUrl": ""},
        "InstagramImages": [],
        "Videos": []
    }
    return jsonify(communityboard_data)

@app.route("/api/avatar/v2/gifts", methods=["GET", "POST"])
def api_avatar_v2_gifts():
    # Return empty array like astrea.mov
    return jsonify([])

@app.route("/api/checklist/v1/current", methods=["GET", "POST"])
def api_checklist_v1_current():
    # Return the checklist data from astrea.mov
    checklist_data = [
        {"Order": 0, "Objective": 400, "Count": 3, "CreditAmount": 200},
        {"Order": 1, "Objective": 1003, "Count": 40, "CreditAmount": 200},
        {"Order": 2, "Objective": 603, "Count": 50, "CreditAmount": 500},
        {"Order": 3, "Objective": 802, "Count": 10, "CreditAmount": 100},
        {"Order": 4, "Objective": 38, "Count": 1, "CreditAmount": 500},
        {"Order": 5, "Objective": 502, "Count": 300, "CreditAmount": 150},
        {"Order": 6, "Objective": 35, "Count": 20, "CreditAmount": 100}
    ]
    return jsonify(checklist_data)

@app.route("/api/rooms/v2/myrooms", methods=["GET", "POST"])
def api_rooms_v2_myrooms():
    # Return empty array like api.astrea.mov
    return jsonify([])

@app.route("/3vltmrmtk3vjyyqkqeln9hdnb.jpg", methods=["GET"])
def serve_profile_image():
    # Fetch image from img.astrea.mov and serve it
    image_url = "https://img.astrea.mov/3vltmrmtk3vjyyqkqeln9hdnb.jpg"
    
    try:
        # Fetch image from external URL with SSL verification disabled for development
        response = requests.get(image_url, timeout=10, verify=False)
        
        if response.status_code == 200:
            # Create Flask response with image data
            from flask import make_response
            flask_response = make_response(response.content)
            flask_response.headers['Content-Type'] = response.headers.get('Content-Type', 'image/jpeg')
            return flask_response
        else:
            print(f"❌ External image returned status: {response.status_code}")
            return "Image not found", 404
            
    except Exception as e:
        print(f"❌ Error fetching image: {e}")
        # Try to serve a local fallback if external fetch fails
        try:
            # Look for any existing profile image in Players directory as fallback
            for player_dir in os.listdir("Players"):
                image_path = os.path.join("Players", player_dir, "profileimage.png")
                if os.path.exists(image_path):
                    with open(image_path, 'rb') as f:
                        from flask import make_response
                        flask_response = make_response(f.read())
                        flask_response.headers['Content-Type'] = 'image/png'
                        return flask_response
                    break
        except:
            pass
        return "Error fetching image", 500

@app.route("/api/storefronts/v3/giftdropstore/3", methods=["GET", "POST"])
def api_storefronts_v3_giftdropstore_3():
    # Return the actual giftdropstore data from astrea.mov
    giftdropstore_data = {
        "StorefrontType": 400,
        "NextUpdate": "2021-05-06T20:25:32.5889204+10:00",
        "StoreItems": [
            {"PurchasableItemId": 9009, "Type": 0, "IsFeatured": False, "Prices": [{"CurrencyType": 2, "Price": 50}], "GiftDrops": [{"GiftDropId": 9009, "FriendlyName": "Paintball Vest (Black)", "Tooltip": "", "AvatarItemDesc": "d8f408f0-78f5-4e8a-b42a-e7b09632d1fd,,,", "ConsumableItemDesc": "", "EquipmentPrefabName": "", "EquipmentModificationGuid": "", "Rarity": 0, "IsQuery": False, "Unique": False, "Level": 1, "Context": 100000}]},
            {"PurchasableItemId": 9004, "Type": 0, "IsFeatured": False, "Prices": [{"CurrencyType": 2, "Price": 95}], "GiftDrops": [{"GiftDropId": 9004, "FriendlyName": "Paintball Vest (Black)", "Tooltip": "", "AvatarItemDesc": "d8f408f0-78f5-4e8a-b42a-e7b09632d1fd,178c6beb-c737-434c-a53b-d14f438f6a98,0189ec4c-0389-4ebc-b9ba-32303a6341c2,", "ConsumableItemDesc": "", "EquipmentPrefabName": "", "EquipmentModificationGuid": "", "Rarity": 0, "IsQuery": False, "Unique": False, "Level": 1, "Context": 100000}]},
            {"PurchasableItemId": 9002, "Type": 0, "IsFeatured": False, "Prices": [{"CurrencyType": 2, "Price": 95}], "GiftDrops": [{"GiftDropId": 9002, "FriendlyName": "Paintball Vest (Red)", "Tooltip": "", "AvatarItemDesc": "d8f408f0-78f5-4e8a-b42a-e7b09632d1fd,2913bd93-bf35-4bdf-b83a-d40a10213adc,0189ec4c-0389-4ebc-b9ba-32303a6341c2,", "ConsumableItemDesc": "", "EquipmentPrefabName": "", "EquipmentModificationGuid": "", "Rarity": 0, "IsQuery": False, "Unique": False, "Level": 1, "Context": 100000}]},
            {"PurchasableItemId": 9005, "Type": 0, "IsFeatured": False, "Prices": [{"CurrencyType": 2, "Price": 90}], "GiftDrops": [{"GiftDropId": 9005, "FriendlyName": "Pepperoni Pizza", "Tooltip": "", "AvatarItemDesc": "", "ConsumableItemDesc": "mq23W-RSP0G8iGNLdrcpUw", "EquipmentPrefabName": "", "EquipmentModificationGuid": "", "Rarity": 0, "IsQuery": False, "Unique": False, "Level": 1, "Context": 100000}]},
            {"PurchasableItemId": 9003, "Type": 0, "IsFeatured": False, "Prices": [{"CurrencyType": 2, "Price": 85}], "GiftDrops": [{"GiftDropId": 9003, "FriendlyName": "Cheese Pizza", "Tooltip": "", "AvatarItemDesc": "", "ConsumableItemDesc": "5hIAZ9wg5EyG1cILf4FS2A", "EquipmentPrefabName": "", "EquipmentModificationGuid": "", "Rarity": 0, "IsQuery": False, "Unique": False, "Level": 1, "Context": 100000}]},
            {"PurchasableItemId": 9001, "Type": 0, "IsFeatured": False, "Prices": [{"CurrencyType": 2, "Price": 90}], "GiftDrops": [{"GiftDropId": 9001, "FriendlyName": "Glazed Donuts", "Tooltip": "", "AvatarItemDesc": "", "ConsumableItemDesc": "7OZ5AE3uuUyqa0P-2W1ptg", "EquipmentPrefabName": "", "EquipmentModificationGuid": "", "Rarity": 0, "IsQuery": False, "Unique": False, "Level": 1, "Context": 100000}]},
            {"PurchasableItemId": 9007, "Type": 0, "IsFeatured": False, "Prices": [{"CurrencyType": 2, "Price": 95}], "GiftDrops": [{"GiftDropId": 9007, "FriendlyName": "Chocolate Frosted Donuts", "Tooltip": "", "AvatarItemDesc": "", "ConsumableItemDesc": "mMCGPgK3tki5S_15q2Z81A", "EquipmentPrefabName": "", "EquipmentModificationGuid": "", "Rarity": 0, "IsQuery": False, "Unique": False, "Level": 1, "Context": 100000}]},
            {"PurchasableItemId": 9006, "Type": 0, "IsFeatured": False, "Prices": [{"CurrencyType": 2, "Price": 100}], "GiftDrops": [{"GiftDropId": 9006, "FriendlyName": "Assorted Donuts", "Tooltip": "", "AvatarItemDesc": "", "ConsumableItemDesc": "ZuvkidodzkuOfGLDnTOFyg", "EquipmentPrefabName": "", "EquipmentModificationGuid": "", "Rarity": 0, "IsQuery": False, "Unique": False, "Level": 1, "Context": 100000}]}
        ]
    }
    return jsonify(giftdropstore_data)

@app.route("/api/quickPlay/v1/getandclear", methods=["GET", "POST"])
def api_quickPlay_v1_getandclear():
    # Return the quickPlay data with player ID and dormroom
    quickplay_data = {
        "TargetPlayerId": 5672149449569020,  # Use the same player ID from other endpoints
        "RoomName": "DormRoom",
        "ActionCode": None
    }
    return jsonify(quickplay_data)

@app.route("/api/images/v2/named", methods=["GET", "POST"])
def api_images_v2_named():
    # Return the actual named images data from astrea.mov
    named_images_data = [
        {"FriendlyImageName": "DormRoomBucket", "ImageName": "b63bcfa3e16042f59e1b2ba40021b9b9", "StartTime": "2021-12-27T21:27:38.188Z", "EndTime": "2026-12-27T21:27:38.188Z"},
        {"FriendlyImageName": "Loft", "ImageName": "b63bcfa3e16042f59e1b2ba40021b9b9", "StartTime": "2021-12-27T21:27:38.188Z", "EndTime": "2026-12-27T21:27:38.188Z"},
        {"FriendlyImageName": "BackStairs", "ImageName": "b63bcfa3e16042f59e1b2ba40021b9b9", "StartTime": "2021-12-27T21:27:38.188Z", "EndTime": "2026-12-27T21:27:38.188Z"}
    ]
    return jsonify(named_images_data)

@app.route("/api/platformlogin/v2/getcachedlogins", methods=["POST"])
def get_cached_logins():
    try:
        print(f"🔍 Request received - Content-Type: {request.content_type}")
        print(f"🔍 Request headers: {dict(request.headers)}")
        
        # Get raw body first
        raw_body = request.get_data(as_text=True)
        print(f"🔍 Raw body: {raw_body}")
        print(f"🔍 Content-Type: {request.content_type}")
        
        # Try to parse as JSON first (even without proper Content-Type)
        try:
            data = json.loads(raw_body)
            platform_id = int(data.get("Platform", 0))
            player_id = int(data.get("PlatformId", 0))
            print(f"🔍 Using JSON - Platform: {platform_id}, PlayerID: {player_id}")
        except (json.JSONDecodeError, ValueError):
            # Fall back to form-encoded data with better URL decoding
            if "&" in raw_body and "=" in raw_body:
                from urllib.parse import unquote_plus
                # Handle URL encoding
                decoded_body = unquote_plus(raw_body)
                print(f"🔍 Decoded body: {decoded_body}")
                
                try:
                    # Split and parse key-value pairs more safely
                    parts = {}
                    for pair in decoded_body.split("&"):
                        if "=" in pair:
                            key, value = pair.split("=", 1)
                            parts[key] = value
                    
                    platform_id = int(parts.get("Platform", parts.get("platform", 0)))
                    player_id = int(parts.get("PlatformId", parts.get("platformId", 0)))
                    print(f"🔍 Using form-encoded - Platform: {platform_id}, PlayerID: {player_id}")
                except (ValueError, KeyError) as e:
                    print(f"🔍 Form parsing error: {e}")
                    platform_id = 0
                    player_id = 0
            else:
                print(f"🔍 Could not parse body: {raw_body}")
                platform_id = 0
                player_id = 0

        # Store player data in memory
        player_data[player_id] = {
            "Id": player_id,
            "Username": "zziver",
            "DisplayName": "zziver",
            "XP": 9999,
            "Level": 70,
            "RegistrationStatus": 2,
            "Developer": False,
            "CanReceiveInvites": False,
            "ProfileImageName": "3vltmrmtk3vjyyqkqeln9hdnb.jpg",
            "JuniorProfile": False,
            "ForceJuniorImages": False,
            "PendingJunior": False,
            "HasBirthday": True,
            "AvoidJuniors": True,
            "PlayerReputation": {
                "Noteriety": 0,
                "CheerGeneral": 10,
                "CheerHelpful": 10,
                "CheerGreatHost": 10,
                "CheerSportsman": 10,
                "CheerCreative": 10,
                "CheerCredit": 20,
                "SubscriberCount": 0,
                "SubscribedCount": 0,
                "SelectedCheer": 0
            },
            "PlatformIds": [
                {
                    "Platform": platform_id,
                    "PlatformId": str(player_id)
                }
            ]
        }

        # Store login data in memory  
        login_key = f"{platform_id}_{player_id}"
        
        # Generate timestamp in format that 2019 client expects (with Z suffix and milliseconds)
        current_time = datetime.utcnow()
        formatted_time = current_time.strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3] + 'Z'
        
        login_cache[login_key] = {
            "platform": platform_id,
            "platformId": str(player_id),
            "accountId": player_id,
            "lastLoginTime": formatted_time,
            "requirePassword": False
        }

        # Build cached logins response - 2019 format with proper field types
        response_data = [{
            "Platform": platform_id,           # Capitalized to match 2019 format
            "PlatformId": str(player_id),      # Always string
            "AccountId": player_id,            # Number for AccountId
            "LastLoginTime": formatted_time,   # Capitalized and proper timestamp format
            "RequirePassword": False,          # Capitalized
            "Player": player_data[player_id]   # Add the Player profile data
        }]

        # Log to Discord
        log_to_discord(
            "🟦 Platform Login v2 Request",
            {
                "method": request.method,
                "path": request.path,
                "ip": request.remote_addr,
                "user_agent": request.headers.get("User-Agent", "unknown"),
                "raw_body": raw_body,
                "player_id": player_id,
                "platform_id": platform_id
            },
            response_data
        )

        return jsonify(response_data), 200

    except Exception as e:
        error_msg = str(e)
        error_type = type(e).__name__
        import traceback
        traceback_info = traceback.format_exc()
        
        print(f"❌ ERROR in get_cached_logins: {error_msg}")
        print(f"❌ Exception type: {error_type}")
        print(f"❌ Traceback: {traceback_info}")
        
        # Log error to Discord
        log_to_discord(
            "🚨 ERROR in Platform Login v2",
            {
                "error_message": error_msg,
                "error_type": error_type,
                "method": request.method,
                "path": request.path,
                "ip": request.remote_addr,
                "user_agent": request.headers.get("User-Agent", "unknown"),
                "raw_body": request.get_data(as_text=True)[:500],  # Limit length
                "traceback": traceback_info[-1000:]  # Last 1000 chars of traceback
            }
        )
        
        return jsonify({"error": error_msg}), 500


# --- Extra routes ---
@app.route("/")
def root():
    return jsonify(services)

@app.route("/api/versioncheck/v3")
def version_check():
    return jsonify({"ValidVersion": True})

@app.route("/api/settings/v2/", methods=["GET"])
def settings_v2():
    settings_data = [
        {"Key":"MOD_BLOCKED_TIME","Value":"0"},
        {"Key":"MOD_BLOCKED_DURATION","Value":"0"},
        {"Key":"PlayerSessionCount","Value":"0"},
        {"Key":"ShowRoomCenter","Value":"1"},
        {"Key":"QualitySettings","Value":"3"},
        {"Key":"Recroom.OOBE","Value":"100"},
        {"Key":"VoiceFilter2","Value":"1"},
        {"Key":"VIGNETTED_TELEPORT_ENABLED","Value":"0"},
        {"Key":"CONTINUOUS_ROTATION_MODE","Value":"0"},
        {"Key":"ROTATION_INCREMENT","Value":"2"},
        {"Key":"ROTATE_IN_PLACE_ENABLED","Value":"1"},
        {"Key":"OOBE_OBJECTIVES_GRANTED","Value":"7"},
        {"Key":"TeleportBuffer","Value":"0"},
        {"Key":"VoiceChat","Value":"2"},
        {"Key":"PersonalBubble","Value":"0"},
        {"Key":"IgnoreBuffer","Value":"0"},
        {"Key":"H.264 plugin","Value":"0"},
        {"Key":"USER_TRACKING","Value":"54"},
        {"Key":"google_analytics_clientid_pref_key","Value":"NUUXQPYRd304666890447385bf0e7fd2fce40b08380243c1"},
        {"Key":"Recroom.ChallengeMap","Value":"0"},
        {"Key":"FIRST_TIME_IN_FLAGS","Value":"0"},
        {"Key":"VR_MOVEMENT_MODE","Value":"1"},
        {"Key":"BACKPACK_FAVORITE_TOOL","Value":"1"},
        {"Key":"COMFORT_WALK","Value":"0"},
        {"Key":"COMFORT_FLY","Value":"0"},
        {"Key":"COMFORT_SMOOTH_ROTATE","Value":"0"},
        {"Key":"COMFORT_SPRINT","Value":"0"},
        {"Key":"COMFORT_VEHICLES","Value":"0"},
        {"Key":"COMFORT_SWIPE_ROTATE","Value":"0"},
        {"Key":"HandMute","Value":"0"},
        {"Key":"PICKED_UP_STICKY_TOOL_BEFORE","Value":"6"},
        {"Key":"SplitTestAssignedSegments","Value":"1|{\"SplitTesting+TokensAndDressUpNUX_2018_07_16\":\"SkipTokensAndDressUpNUX\"}"},
        {"Key":"GIFT_COUNT","Value":"1"},
        {"Key":"DAILY_LOGIN_DATE","Value":"187"},
        {"Key":"OBJECTIVE_DATE","Value":"187"},
        {"Key":"OBJECTIVE_PROGRESS0","Value":"0"},
        {"Key":"OBJECTIVE_COMPLETED0","Value":"0"},
        {"Key":"OBJECTIVE_PROGRESS1","Value":"0"},
        {"Key":"OBJECTIVE_COMPLETED1","Value":"0"},
        {"Key":"OBJECTIVE_PROGRESS2","Value":"0"},
        {"Key":"OBJECTIVE_COMPLETED2","Value":"0"},
        {"Key":"VoiceFilter","Value":"2"},
        {"Key":"PlayerHeight","Value":"1.5"},
        {"Key":"TOUCHPAD_TELEPORT_ENABLED","Value":"0"},
        {"Key":"GIFT_DATE","Value":"187"}
    ]
    return jsonify(settings_data)

@app.route("/api/config/v1/amplitude")
def amplitude_check():
    return jsonify({"AmplitudeKey":"AstreaNetKey"})

@app.route("/api/gameconfigs/v1/all")
def game_configs_all():
    return jsonify(game_configs)

@app.route("/api/avatar/v2", methods=["GET"])
def avatar_v2():
    avatar_data = {
        "OutfitSelections": "2e59d8d0-91a0-4449-bfdc-a5d663fd9343,4398ce1a-e6ee-4da4-ad0d-7abfab41020c,,,1;3d5184e1-0201-4476-bf4b-4eb28190de62,4398ce1a-e6ee-4da4-ad0d-7abfab41020c,,,0;bu9tb-K7NEiocvZY3o7ukw,4398ce1a-e6ee-4da4-ad0d-7abfab41020c,,,0;2cb4f372-3372-4583-8b57-c4e3988e3c28,4398ce1a-e6ee-4da4-ad0d-7abfab41020c,,,0;e15b13a7-9e9a-4b32-ba2c-0cb31ed55a8c,4398ce1a-e6ee-4da4-ad0d-7abfab41020c,,,1;7a6fe0e6-f930-4fb8-9b2f-4c857a273dd9,4398ce1a-e6ee-4da4-ad0d-7abfab41020c,,,2;7a6fe0e6-f930-4fb8-9b2f-4c857a273dd9,4398ce1a-e6ee-4da4-ad0d-7abfab41020c,,,3;",
        "FaceFeatures": "{\"ver\":3,\"eyeId\":\"AjGMoJhEcEehacRZjUMuDg\",\"eyePos\":{\"x\":0.0,\"y\":0.019999999552965165},\"eyeScl\":0.05000000074505806,\"mouthId\":\"pc1z8k98X0ae0Nab-IKhfA\",\"mouthPos\":{\"x\":0.0,\"y\":0.09999999403953552},\"mouthScl\":0.05000000074505806,\"beardColorId\":\"5ee30295-b05f-4e96-819e-5ac865b2c63d\"}",
        "SkinColor": "85343b16-d58a-4091-96d8-083a81fb03ae",
        "HairColor": "3Q8U6E5pV0uzK141ut2WBg"
    }
    return jsonify(avatar_data)

@app.route("/debug/cache")
def debug_cache():
    return jsonify({
        "login_cache": login_cache,
        "player_data": player_data
    })

# Profile endpoints that Rec Room client likely needs
@app.route("/api/accounts/v1/getmyplayer", methods=["GET", "POST"])
def get_my_player():
    # Return the player's own profile data
    player_id = 5672149449569020  # Use your platform ID
    if player_id in player_data:
        return jsonify(player_data[player_id])
    else:
        # Return default profile if not cached
        return jsonify({
            "accountId": player_id,
            "username": f"User{player_id}",
            "displayName": f"User{player_id}",
            "profileImage": "3vltmrmtk3vjyyqkqeln9hdnb.jpg",
            "bannerImage": "3vltmrmtk3vjyyqkqeln9hdnb.jpg",
            "isJunior": False,
            "platforms": 1,
            "personalPronouns": 0,
            "identityFlags": 0,
            "createdAt": datetime.utcnow().isoformat(),
            "isMetaPlatformBlocked": False
        })

@app.route("/api/accounts/v1/account/<account_id>", methods=["GET"])
def get_account(account_id):
    account_id = int(account_id)
    if account_id in player_data:
        return jsonify(player_data[account_id])
    else:
        return jsonify({
            "accountId": account_id,
            "username": f"User{account_id}",
            "displayName": f"User{account_id}",
            "profileImage": "3vltmrmtk3vjyyqkqeln9hdnb.jpg",
            "bannerImage": "3vltmrmtk3vjyyqkqeln9hdnb.jpg",
            "isJunior": False,
            "platforms": 1,
            "personalPronouns": 0,
            "identityFlags": 0,
            "createdAt": datetime.utcnow().isoformat(),
            "isMetaPlatformBlocked": False
        })

# Hub negotiation endpoints - more specific routes first!
@app.route("/hub/v1/negotiate", methods=["POST", "GET"])
def hub_v1_negotiate():
    # Get raw body like in C# implementation
    raw_body = request.get_data(as_text=True)
    raw_url = request.path
    
    if raw_body:
        print("🔗 Hub v1/negotiate - Notifications Requested: " + raw_body)
    else:
        print("🔗 Hub v1/negotiate - Notifications Requested (rawUrl): " + raw_url)
    
    # Match the NegotiationResult C# class exactly
    import uuid
    connection_id = str(uuid.uuid4())
    data = {
        "ConnectionId": connection_id,
        "SupportedTransports": [],
        "Url": "astrea.mov",
        "AccessToken": "Token like rec room?! (we don't need this rn)"
    }
    
    print("🔗 Hub v1/negotiate - Data: " + raw_body)
    print("🔗 Hub v1/negotiate - Response: " + json.dumps(data))
    return jsonify(data)

@app.route("/hub/v1", methods=["GET"])
def hub_v1():
    data = {
        "negotiateVersion": 0,
        "connectionId": "uwu",
        "availableTransports": [
            {
                "transport": "WebSockets",
                "transferFormats": [
                    "Text",
                    "Binary"
                ]
            }
        ]
    }
    return jsonify(data)

@app.route("/api/consumables/v1/getUnlocked", methods=["GET"])
def get_unlocked_consumables():
    consumables_data = [
        {"Id":1,"Ids":[1],"ConsumableItemDesc":"7OZ5AE3uuUyqa0P-2W1ptg","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":2,"Ids":[2],"ConsumableItemDesc":"_jnjYGBcyEWY5Ub4OezXcA","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":3,"Ids":[3],"ConsumableItemDesc":"5hIAZ9wg5EyG1cILf4FS2A","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":4,"Ids":[4],"ConsumableItemDesc":"wUCIKdJSvEmiQHYMyx4X4w","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":5,"Ids":[5],"ConsumableItemDesc":"JfnVXFmilU6ysv-VbTAe3A","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":6,"Ids":[6],"ConsumableItemDesc":"InQ25wQMGkG_bvuD5rf2Ag","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":7,"Ids":[7],"ConsumableItemDesc":"mMCGPgK3tki5S_15q2Z81A","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":8,"Ids":[8],"ConsumableItemDesc":"ZuvkidodzkuOfGLDnTOFyg","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":9,"Ids":[9],"ConsumableItemDesc":"VQSgL2pTLkWx4B3kwYG7UA","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":10,"Ids":[10],"ConsumableItemDesc":"Tpxqe_lycUelySRHM8B0Vw","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":11,"Ids":[11],"ConsumableItemDesc":"-hy0qD-iUk-v4NHxNzanmg","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":12,"Ids":[12],"ConsumableItemDesc":"6SyCoJCgo0Wd6qlPlnMOtg","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":13,"Ids":[13],"ConsumableItemDesc":"A5M-yf9tgUihq1uab3v58g","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":14,"Ids":[14],"ConsumableItemDesc":"1c0Djlp090uBDczEobYNQw","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":15,"Ids":[15],"ConsumableItemDesc":"frOMH6WxDEG1fBqC4_83vg","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":16,"Ids":[16],"ConsumableItemDesc":"m0bVLwWGj0GuIBSb6wCk6Q","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":17,"Ids":[17],"ConsumableItemDesc":"mL3zCEuy2UWZxAV4V-OsMA","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":18,"Ids":[18],"ConsumableItemDesc":"mq23W-RSP0G8iGNLdrcpUw","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":19,"Ids":[19],"ConsumableItemDesc":"ZtZnYBpKkECJlhHmkj4MiA","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":20,"Ids":[20],"ConsumableItemDesc":"g3kxdlJv5kO8PuBXveM48w","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":21,"Ids":[21],"ConsumableItemDesc":"wx--2TPTdEuGAqLCjs9Qag","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":22,"Ids":[22],"ConsumableItemDesc":"xHOwjwpXd0GDkvBz2VqieA","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":23,"Ids":[23],"ConsumableItemDesc":"Il4VmrnjDkqjmjzddqoIEw","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":24,"Ids":[24],"ConsumableItemDesc":"XOZcxx-Klkyhe-MDbTqiwA","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":25,"Ids":[25],"ConsumableItemDesc":"JwJeh15cjkOc9WWaGRibDQ","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":26,"Ids":[26],"ConsumableItemDesc":"x9ntSHto50GpNWPwYCLUEg","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":27,"Ids":[27],"ConsumableItemDesc":"8vlVslaWaUyFS-iDHhxW9g","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":28,"Ids":[28],"ConsumableItemDesc":"eJh_BQ5y4UWwiMJzBKcwMQ","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":29,"Ids":[29],"ConsumableItemDesc":"iEtWDLmv7ES87J4NE_TGJQ","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":30,"Ids":[30],"ConsumableItemDesc":"3R1bzI35fkChoFFRFbponQ","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":31,"Ids":[31],"ConsumableItemDesc":"YaVzcoefhk6zjbNDELLx8A","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":32,"Ids":[32],"ConsumableItemDesc":"xr45B5QC4EyKXThtwZto_A","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":33,"Ids":[33],"ConsumableItemDesc":"UAOH6ccEbEmehJg8XW_D8w","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":34,"Ids":[34],"ConsumableItemDesc":"P7HixsdkskmzgFMdFJ-WdA","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":35,"Ids":[35],"ConsumableItemDesc":"jA3zzS31zEitBxtRCk7oew","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":36,"Ids":[36],"ConsumableItemDesc":"AQTYAh1it0GIGdgGO5sUHQ","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":37,"Ids":[37],"ConsumableItemDesc":"s2pxukIEt0uDeGVJmZayOw","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":38,"Ids":[38],"ConsumableItemDesc":"Hh_O_RejGE-_PubyM8xHaw","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":39,"Ids":[39],"ConsumableItemDesc":"STFKahjHJ0SQJPfoDe4S1g","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":40,"Ids":[40],"ConsumableItemDesc":"4L3JoaqkAUa1kz98nciPXw","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":41,"Ids":[41],"ConsumableItemDesc":"inIuPzhhOEmz1RI8mZtSLg","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":42,"Ids":[42],"ConsumableItemDesc":"vXL0rrAk70SFxJlaJk0uqQ","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":43,"Ids":[43],"ConsumableItemDesc":"xRtKWR-D40GUW43R0EFpNg","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":44,"Ids":[44],"ConsumableItemDesc":"P1kCuPlRc0-NAg6JUlEH_g","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":45,"Ids":[45],"ConsumableItemDesc":"5Ugg8k19n0WH8GPFCDWTCQ","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":46,"Ids":[46],"ConsumableItemDesc":"o0hG5O_eaUO0R8vPyW-Hvg","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":47,"Ids":[47],"ConsumableItemDesc":"uGVFydNSokCXFAmXu3aceQ","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":48,"Ids":[48],"ConsumableItemDesc":"yvqSbK2czkS2sUCRdrGaEw","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":49,"Ids":[49],"ConsumableItemDesc":"EAhk3ZZdXEmH5wRAXXT24Q","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":50,"Ids":[50],"ConsumableItemDesc":"Av-wvjXvvkmNVSz7ZZnTiA","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":51,"Ids":[51],"ConsumableItemDesc":"5AJin8T2iEG7BzOPOgx2HA","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":52,"Ids":[52],"ConsumableItemDesc":"U38Qe6rhEk6mFvArHfYjng","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":53,"Ids":[53],"ConsumableItemDesc":"uMHrUPLYFk2rJOW_uop5Aw","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":54,"Ids":[54],"ConsumableItemDesc":"lag2tZyB90W04lQ7ol4vMw","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":55,"Ids":[55],"ConsumableItemDesc":"oG7CdvW7p0-S8sVe9w5vRw","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":56,"Ids":[56],"ConsumableItemDesc":"QRx0aSTT9keMFdAJMQHdTg","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4},
        {"Id":57,"Ids":[57],"ConsumableItemDesc":"iiGTvhOCHkOTNJhb16Zbyw","PlatformMask":-1,"CreatedAt":"2022-02-19T05:29:59.909Z","CreatedAts":["2022-02-19T05:29:59.909Z"],"Count":999,"InitialCount":999,"UnlockedLevel":0,"IsActive":False,"IsTransferable":True,"Category":4}
    ]
    return jsonify(consumables_data)

# Fake WebSocket endpoints - HTTP endpoints that simulate WebSocket behavior
@app.route("/ws/connect", methods=["POST", "GET"])
def fake_websocket_connect():
    connection_id = request.args.get('id', 'fake-connection-id')
    print(f"🔌 Fake WebSocket connection established for ID: {connection_id}")
    return jsonify({
        "status": "connected",
        "connectionId": connection_id,
        "message": "Connected to DIH server"
    })

@app.route("/api/relationships/v2/get", methods=["GET"])
def apirelationshipsv2get():
    data = []
    return jsonify(data)

@app.route("/api/messages/v2/get", methods=["GET"])
def apimessagesv3get():
    return jsonify([])

@app.route("/api/chat/v2/myChats", methods=["GET"])
def apimessagesv2get():
    return jsonify([])

@app.route("/api/settings/v2/set", methods=["POST"])
def apisettint():
    return jsonify([])

@app.route("/api/playersubscriptions/v1/my", methods=["GET"])
def apisubget():
    return jsonify([])

@app.route("/player/heartbeat", methods=["POST", "GET"])
def player_heartbeat():
    try:
        # Get LoginLock parameter from either query params or form data
        login_lock = request.args.get('LoginLock') or request.form.get('LoginLock')
        
        # If not in query params or form, try to parse from raw body
        if not login_lock:
            raw_body = request.get_data(as_text=True)
            if raw_body and "LoginLock=" in raw_body:
                from urllib.parse import parse_qs, unquote_plus
                decoded_body = unquote_plus(raw_body)
                params = {}
                for pair in decoded_body.split("&"):
                    if "=" in pair:
                        key, value = pair.split("=", 1)
                        params[key] = value
                login_lock = params.get("LoginLock")
        
        print(f"💓 Heartbeat request - LoginLock: {login_lock}")
        
        # Return heartbeat data with actual player ID
        heartbeat_data = {
            "playerId": 5672149449569020,  # Return actual player ID instead of null
            "statusVisibility": 0,
            "deviceClass": 0,
            "roomInstance": {
                "roomInstanceId": 403940429,
                "roomId": 8,
                "subRoomId": 1,
                "roomInstanceType": 0,
                "location": "e122fe98-e7db-49e8-a1b1-105424b6e1f0",
                "photonRegionId": "us",
                "photonRoomId": "astrea.26038243",
                "name": "Paintball",
                "maxCapacity": 8,
                "dataBlob": "",
                "isFull": False,
                "isPrivate": False,
                "isInProgress": False
            },
            "isOnline": True
        }
        
        print(f"💓 Heartbeat response - Player ID: {heartbeat_data['playerId']}")
        return jsonify(heartbeat_data)
        
    except Exception as e:
        error_msg = str(e)
        print(f"❌ ERROR in player_heartbeat: {error_msg}")
        
        # Return error response
        return jsonify({
            "error": f"Heartbeat failed: {error_msg}"
        }), 500

@app.route("/ws/send", methods=["POST"])
def fake_websocket_send():
    raw_body = request.get_data(as_text=True)
    print(f"🔔 Fake WebSocket received: {raw_body}")
    return jsonify({
        "status": "received",
        "echo": raw_body,
        "response": "Message processed by fake WebSocket"
    })

@app.route("/ws/disconnect", methods=["POST", "GET"])
def fake_websocket_disconnect():
    connection_id = request.args.get('id', 'fake-connection-id')
    print(f"🔌 Fake WebSocket disconnected for ID: {connection_id}")
    return jsonify({
        "status": "disconnected",
        "connectionId": connection_id
    })

@app.route("/versioncheck", methods=["GET", "POST"])
def notifications_versioncheck():
    # Match the C# VersionCheckResponse
    raw_body = request.get_data(as_text=True)
    raw_url = request.path
    
    if raw_body:
        print("Notifications Requested: " + raw_body)
    else:
        print("Notifications Requested (rawUrl): " + raw_url)
    
    response_data = {"ValidVersion": True}
    print("Notifications Data: " + raw_body)
    print("Notifications Response: ")
    return jsonify(response_data)

# --- New room goto endpoint with JWT authentication ---
@app.route("/goto/room/DormRoom", methods=["POST"])
def match_goto_room(RoomName):
    try:
        # Get Authorization header
        authorization = request.headers.get("Authorization")
        if not authorization or not authorization.startswith("Bearer "):
            log_to_discord(
                "🚨 Unauthorized Access",
                {
                    "room_name": RoomName,
                    "method": request.method,
                    "path": request.path,
                    "ip": request.remote_addr,
                    "authorization": authorization
                }
            )
            return jsonify({"error": "Unauthorized"}), 401
        
        # Decode JWT token (using simple decode without verification for demo)
        try:
            token_str = authorization.split("Bearer ")[1]
            # For development, decode without verification
            token = jwt.decode(token_str, options={"verify_signature": False})
        except Exception as jwt_error:
            log_to_discord(
                "🚨 JWT Decode Failed",
                {
                    "room_name": RoomName,
                    "jwt_error": str(jwt_error),
                    "method": request.method,
                    "path": request.path,
                    "ip": request.remote_addr
                }
            )
            return jsonify({"error": "Invalid token"}), 401
        
        # Get player data from token or default
        player_id = token.get("sub", 1)  # Default to player ID 1
        player_data_obj = {
            "accountId": player_id,
            "username": f"User{player_id}",
            "displayName": f"User{player_id}"
        }
        
        # Check if room exists
        room = rooms_data.get(RoomName)
        if room is None:
            log_to_discord(
                "🚨 Room Not Found",
                {
                    "room_name": RoomName,
                    "player_id": player_id,
                    "method": request.method,
                    "path": request.path,
                    "ip": request.remote_addr
                }
            )
            return jsonify({"error": "Room not found"}), 404
        
        # Generate room instance data
        roomInstanceId = random.randint(100000000, 999999999)
        
        # Set room name based on room type
        if str(room["Name"]).lower() == "dormroom":
            name = f"@{player_data_obj['username']}'s DormRoom"
        else:
            name = room["Name"]
        
        localRoomInstance = {
            "roomInstanceId": roomInstanceId,
            "roomId": room["RoomId"],
            "subRoomId": room["SubRooms"][0]["SubRoomId"],
            "location": room["SubRooms"][0]["UnitySceneId"],
            "roomInstanceType": 0,
            "photonRegionId": "us",
            "photonRegion": "us",
            "photonRoomId": "OldRecRoom2022-" + room["Name"] + str(room["SubRooms"][0]["SubRoomId"]) + str(room["RoomId"]),
            "name": name,
            "maxCapacity": 4,
            "isFull": False,
            "isPrivate": False,
            "isInProgress": False,
            "matchmakingPolicy": 0
        }
        
        # Update heartbeat data
        for heartbeat in heartbeat_data:
            if heartbeat["playerId"] == int(player_id):
                heartbeat.update({
                    "roomInstance": localRoomInstance,
                    "isOnline": True
                })
                break
        else:
            # Add new heartbeat entry if player not found
            heartbeat_data.append({
                "playerId": int(player_id),
                "statusVisibility": 3,
                "platform": -1,
                "deviceClass": 0,
                "vrMovementMode": 0,
                "roomInstance": localRoomInstance,
                "lastOnline": datetime.utcnow().isoformat(),
                "isOnline": True,
                "appVersion": 20210804
            })
        
        # Log to Discord using existing logging function
        log_to_discord(
            "🎮 Matchmaking - Room Join",
            {
                "player_username": player_data_obj['username'],
                "player_display_name": player_data_obj['displayName'], 
                "player_id": player_data_obj['accountId'],
                "room_name": localRoomInstance['name'],
                "room_instance_id": roomInstanceId,
                "photon_room_id": localRoomInstance['photonRoomId'],
                "method": request.method,
                "path": request.path,
                "ip": request.remote_addr
            }
        )
        
        # Return response
        response_data = {
            "errorCode": 0,
            "roomInstance": localRoomInstance
        }
        
        print(f"🎮 Room join successful - Player: {player_data_obj['username']}, Room: {name}")
        return jsonify(response_data)
        
    except Exception as e:
        error_msg = str(e)
        print(f"❌ ERROR in match_goto_room: {error_msg}")
        
        # Log error to Discord
        log_to_discord(
            "🚨 ERROR - Room Join Failed",
            {
                "error_message": error_msg,
                "room_name": RoomName,
                "method": request.method,
                "path": request.path,
                "ip": request.remote_addr,
                "user_agent": request.headers.get('User-Agent', 'unknown')
            }
        )
        
        return abort(500)

# Catch-all route for any unmatched endpoints - returns null with 200 status
@app.route('/<path:path>', methods=['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH'])
def catch_all(path):
    print(f"🔍 Unmatched endpoint: /{path}")
    return jsonify(None), 200



if __name__ == "__main__":
    os.makedirs("Players", exist_ok=True)
    socketio.run(app, host="0.0.0.0", port=5000, use_reloader=False, log_output=True, allow_unsafe_werkzeug=True)
